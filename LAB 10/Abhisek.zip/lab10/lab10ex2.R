qCheck<-function(N)
{
  r<-c(rnorm(N,10,0.2)) #r is used notation for radius
  color<-c(rbinom(N,1,.995))#generates sequence of 1 and 0
  tested<-c((rbinom(N,1,.3))) #1 indicates selected for testing
  counter_def<-0 #counter for total no.of defective items
  counter_1<-0 #counter for correctly made but marked as defective items
  counter_2<-0 #counter for incorrect radius or incorrect color but not marked as defective items
  counter_3<-0 #counter for incorrect radius or incorrect color
  
  for(i in seq(1:N)) #radius testing
  {
    
    if(tested[i]==1 && (9.7<=r[i] && r[i]<=10.3))
    {
      if (rbinom(1,1,0.001)==1)
      {
        tested[i]<-tested[i]+2
      }
      else
      {
        tested[i]<-tested[i]+1 
      }
    }
    if(tested[i]==1&& (r[i]>10.3 || r[i]<9.7) )
    {
      if (rbinom(1,1,0.95) == 1)
      {
        tested[i]<-tested[i]+2 
      }
      else
      {
        tested[i]<-tested[i]+1 
      }
    }
    
  }
  
  for(i in seq(1:N)) #color testing
  {
    
    if(tested[i]==2 && color[i]==1 ) 
    {
      if (rbinom(1,1,0.005) ==1)
      {
        tested[i]<-tested[i]+1 
      }
      else
      {
        tested[i]<-tested[i]-2 
      }
    }
    if(tested[i]==2 && color[i]!=1 )
    {
      if (rbinom(1,1,0.99) == 1)
      {
        tested[i]<-tested[i]+1 
      }
      else
      {
        tested[i]<-tested[i]-2 
      }
    }
  }
  tested <- tested/3
  for(i in seq(1:N))
  {
    if(tested[i]==1)
    {
      counter_def<-counter_def+1
    }
    if(tested[i]==1 && color[i]==1 && r[i]<=10.3 && r[i]>=9.7)
    {
      counter_1<-counter_1+1
    }
    if(tested[i]==0 &&( color[i]==0 ||r[i]>10.3 || r[i]<9.7))
    {
      counter_2<-counter_2+1
    }
    if(color[i]==0 || (r[i]>10.3 || r[i]<9.7))
    {
       counter_3<-counter_3+1  
    }
  }
  print ("fraction of  defective items")
  print(counter_def/N)
  print("fraction correctly made but marked as defective items")
  print(counter_1/N)
  print("fraction having incorrect radius or incorrect color but not marked as defective")
  print(counter_2/N)
  print("fraction having incorrect radius or incorrect color ")
  print(counter_3/N)
  return(tested)
  
}

qCheck(1000)
