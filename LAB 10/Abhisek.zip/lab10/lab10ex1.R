n <-as.integer(readline(prompt = 'enter the number for n'))
p <-as.numeric(readline(prompt = 'enter the value of p'))
binom<-function(n,p) #binom is used for defining binomial function
{
  x<-rbinom(1000,n,p)
  return(x)
}
y<-binom(n,p) 
bern<-function(n,p)  #bern is used for defining bernaulli function
{
  z<-sum(rbinom(1,n,p))
  return(z)
}
runs<-seq(1:1000)
bern_vctr<-c() #taking a vector which take sum of bernaulli random variables
for(i in runs)
{
  bern_vctr<-append(bern_vctr,bern(n,p))
}
hist(y,main = 'histogram of binomial RV')
hist(bern_vctr,main = 'histogram of sum of bernaulli RV')